export class Company {}
